export class Company {}
